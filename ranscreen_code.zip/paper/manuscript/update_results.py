import re
p = '/home/claude/paper/manuscript/part_b.js'
s = open(p).read()

start = s.index("C.push(H2('6.4 The estimator family'));")
end = s.index("C.push(H1('7. Discussion and limitations'));")

new = """C.push(H2('6.4 The estimator family'));
C.push(...table([2200,1500,1500,1500,1500,1500],[
['Estimator','Worst cov. 4G','charged','Worst cov. 5G','charged','Mean charge'],
['Inverse propensity scoring','0.952','0.952','0.948','0.948','0.061 / 0.073'],
['Self-normalised','0.000','0.936','0.000','0.952','0.061 / 0.073'],
['Doubly robust','0.000','0.944','0.000','0.940','0.061 / 0.073'],
['Switch-DR','0.000','0.944','0.000','0.948','0.102 / 0.120'],
['Optimistic shrinkage','0.000','1.000','0.000','1.000','0.194 / 0.216']],
'Table 3. Theorem 3 applied across the published estimator family on both corpora, 250 logs per cell. Every estimator that distorts the weight fails without the charge and is repaired by it; the charge column gives the mean price the certificate pays, 4G / 5G.'));
C.push(P('One correction repairs the family, and it does so identically on two independent corpora. The charge also ranks the transforms, and the ranking is not the estimation-error ranking. Hard truncation charges 0.061 on 4G and 0.073 on 5G; switching charges roughly twice that; continuous shrinkage charges 0.194 and 0.216 because it distorts every weight rather than only the tail. The consequence is stark: shrinkage has the highest uncorrected acceptance rate in the table, 1.000 on both corpora, and once charged it accepts nothing at all. A transform selected for mean squared error is not necessarily a transform one can certify with, and the charge is the quantity that decides which is which.'));
C.push(H2('6.5 The certifiability frontier'));
C.push(P('Because the charge depends only on the two policies, the frontier Delta = 2 r_max cbar is computable in advance. Measured over a grid of candidate settings, the fraction that are certifiable rises with the exploration the incumbent retains: at temperature 0.2, 11% of settings have a positive gain and none are certifiable; at 0.8, 31% are positive and 19% certifiable; at 2.0, 58% are positive and all of them are certifiable. The largest hysteresis distance that can be certified grows from 1 dB to 3 dB over the same range. Validated against the realised gate on 40 settings with 60 logs each, the prediction agrees in 97.5% of settings on both corpora.'));
C.push(H2('6.6 Which diagnostic predicts failure'));
C.push(...table([2600,2000,2000,2200],[
['Diagnostic','Separates (4G)','Balanced accuracy (4G)','Balanced accuracy (5G)'],
['Effective sample size','no','—','—'],
['Maximum importance weight','no','0.940','0.957'],
['Charge cbar','yes','1.000','0.957']],
'Table 4. Ability of a single threshold to separate cells whose coverage is below nominal from those clearly above it.'));
C.push(P('The effective sample size never separates on either corpus. The charge separates perfectly on 4G and ties the maximum weight on 5G, and unlike either alternative it is motivated rather than heuristic: it is the bias bound itself, and it is available before the log is collected. We therefore key the abstention branch of the gate to the charge, while noting that on 5G no single threshold on any of the three quantities is perfect.'));
C.push(H2('6.7 Deployment-regime shift'));
C.push(...table([2600,2100,2100,2000],[
['Audited against','4G','5G','Remedy'],
['Logging regime (src = dst)','0.803','0.813','charge raises to 0.978 / 0.967'],
['Deployment regime (src ≠ dst)','0.587','0.521','charge raises only to 0.723 / 0.648']],
'Table 5. Mean coverage when the certificate computed on logs from one mobility regime is audited against the truth in the regime where the policy is deployed.'));
C.push(P('An operator tunes on one part of the network and deploys on another, and the certificate does not travel. Within a regime the charged certificate is at or above its nominal level on both corpora; across regimes it loses roughly a quarter of its coverage on 4G and a third on 5G, and the charge repairs only part of the gap. The failure is of a different kind from the one Theorem 3 addresses: it is a shift in the context distribution rather than a distortion of the weight, and our correction is not designed for it. We state it as an open problem, with the practical recommendation that certificates be computed per regime and not transported.'));
C.push(H2('6.8 Monitoring'));
C.push(...table([1600,2100,2100,2100],[
['Truncation M','Fixed-n, monitored (4G / 5G)','Confidence sequence (4G / 5G)','CS acceptance (4G / 5G)'],
['20','0.677 / 0.613','1.000 / 1.000','0.000 / 0.394'],
['5','0.677 / 0.613','1.000 / 1.000','0.500 / 0.600'],
['2','0.677 / 0.613','1.000 / 1.000','0.629 / 0.606']],
'Table 6. Worst-case coverage under monitoring at 25 checkpoints, and the acceptance rate of the betting confidence sequence where the candidate is genuinely better.'));
C.push(P('Evaluated once at a pre-specified sample size the fixed-n certificate covers at 0.935 on 4G and 0.903 on 5G; monitored at 25 checkpoints the same bound falls to 0.677 and 0.613. Optional stopping is therefore a failure mode in its own right, and it is the mode closest to how an operator actually behaves. The betting confidence sequence holds at 1.000 under the same monitoring on both corpora, as its construction guarantees.'));
C.push(P('Its power, however, is governed by the truncation level in a way the fixed-n certificate is not. At M = 20 the sequence accepts nothing on 4G and 39% of the time on 5G; at M = 2 it accepts 63% and 61% respectively, with coverage unchanged at 1.000. The width of a betting sequence scales with the a priori bound on the statistic, which Proposition 2 sets at M + 1, so the level that is best for a fixed-sample certificate is far from the level that is best for an anytime-valid one. Anytime validity is affordable here, but only at a truncation level an order of magnitude tighter than the conventional choice.'));
C.push(H2('6.9 The sequential horizon'));
C.push(...table([1500,1700,1700,1700,1700],[
['Window k','4G bias','4G cov. / acc.','5G bias','5G cov. / acc.'],
['1','−0.0102','0.967 / 1.00','+0.1377','0.000 / 1.00'],
['2','−0.0311','1.000 / 0.22','+0.1024','0.000 / 1.00'],
['3','−0.0323','1.000 / 0.13','+0.0850','0.017 / 1.00'],
['5','−0.0385','1.000 / 0.05','+0.0579','0.650 / 0.98'],
['10','−0.0786','1.000 / 0.00','−0.0160','1.000 / 0.10'],
['40 (full)','−0.3837','1.000 / 0.00','−0.4901','1.000 / 0.00']],
'Table 7. Windowed per-decision importance sampling at horizon 40, incumbent temperature 1.2, conservative candidate (true gain +0.049 on 4G, +0.078 on 5G).'));
C.push(P('Full per-decision importance sampling is valid and useless at this horizon on both corpora: it accepts nothing. Shortening the window restores acceptance, and on the 4G corpus it does so safely, since the bias is downward, which is the conservative direction for a lower bound. On the 5G corpus it does not. There the bias at short windows is upward and large, the certificate covers at 0.000 while accepting in every run, and only at k = 10 does validity return, by which point acceptance has collapsed to 0.10. Counting across all cells, five of eighteen show an upward bias at k = 1 on 4G, against six or seven at every window below ten on 5G.'));
C.push(P('We therefore do not recommend a window length. The windowed estimator recovers power, and whether it does so safely depends on the mixing of the induced chain, which differs between the two networks and is not something the operator can read off the logs. Proposition 8 bounds the bias but does not sign it, and our measurements show both signs occurring. For sequential screening the honest position is that no estimator we tested is simultaneously valid and useful on both corpora, and that this remains the principal open problem of the paper.'));

"""
s = s[:start] + new + s[end:]
open(p, 'w').write(s)
print('results sections updated with both corpora')
