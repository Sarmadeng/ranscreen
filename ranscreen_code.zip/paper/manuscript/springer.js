// Springer (Journal of Network and Systems Management) front matter and reference styling.
// Requirements taken from the journal's submission guidelines: numbered references in order of
// appearance with DOIs as full links, abstract of 150-250 words, 4-6 keywords, author contribution
// and declarations on the title page, figure captions starting with a bold "Fig." and number.
const {Paragraph,TextRun,HeadingLevel,AlignmentType,PageBreak}=require('docx');
const NAVY='1F3864';

const P=(t,o={})=>new Paragraph({alignment:o.align||AlignmentType.JUSTIFIED,
 spacing:{after:o.after===undefined?120:o.after,line:o.line||276},
 children:[new TextRun({text:t,font:'Times New Roman',size:o.size||22,bold:o.bold,italics:o.italics,color:o.color})]});

const HEAD=t=>new Paragraph({spacing:{before:260,after:120},
 children:[new TextRun({text:t,font:'Times New Roman',size:24,bold:true,color:NAVY})]});

function titlePage(){
  const C=[];
  C.push(new Paragraph({alignment:AlignmentType.LEFT,spacing:{before:200,after:200},
    children:[new TextRun({text:'Certified counterfactual screening of AI-driven handover control policies in self-optimizing radio access networks',
      font:'Times New Roman',size:30,bold:true,color:NAVY})]}));

  C.push(P('Fatimah Azeez Rawdhan1 · Sarmad K. Ibrahim1',{size:23,after:140}));
  C.push(P('1 Department of Computer Engineering and Artificial Intelligence, College of Engineering, Mustansiriyah University, Baghdad, Iraq',{size:20,after:60}));
  C.push(P('Corresponding author: Sarmad K. Ibrahim — eng_sarmadnet@uomustansiriyah.edu.iq',{size:20,after:60}));
  C.push(P('ORCID: [add each author’s ORCID iD if available]',{size:20,italics:true,after:220}));

  C.push(HEAD('Abstract'));
  // 150-250 words, as the journal requires; no undefined abbreviations, no citations.
  C.push(P('Autonomous controllers increasingly propose changes to radio access network configuration, and an operator must decide whether to deploy a proposal without exposing live users to it. Counterfactual evaluation answers that question from logged decisions alone, and the decision is licensed by a high-confidence lower bound that the literature treats as a guarantee. We test that guarantee on two public measurement corpora, 92,126 samples from 132 fourth-generation traces and 144,333 from 83 fifth-generation traces, across 60 operating points with 500 independent logs each. The standard doubly-robust certificate falls below its nominal 95 per cent level at 25 and 21 operating points respectively, reaching coverage of zero with a 95 per cent interval of [0.000, 0.008]. The failure deepens as logs grow, from 0.358 at one thousand decisions to 0.014 at twenty thousand, is driven by an importance-weight tail carrying under 0.4 per cent of samples, and is not detected by the effective sample size. We prove an exact identity for the truncation bias and show that the correction it licenses must be charged through its conditional expectation, which has a division-free closed form bounded in the unit interval and remains finite where the logging policy has no support. Charging it this way lifts worst-case coverage to 0.926 and 0.936 with power unchanged. A generalisation to any weight transform repairs the published estimator family, and because the charge depends only on the two policies it predicts screenability before any log is collected.',{after:160}));

  C.push(HEAD('Keywords'));
  C.push(P('Off-policy evaluation · Network management · Handover control · Deployment safety · Concentration inequalities · Confidence sequences',{after:200}));

  C.push(HEAD('Declarations'));
  C.push(P('Funding. ',{bold:true,after:40}));
  C.push(P('This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors.'));
  C.push(P('Competing interests. ',{bold:true,after:40}));
  C.push(P('The authors declare that they have no competing financial or non-financial interests related to the work reported in this paper.'));
  C.push(P('Author contributions. ',{bold:true,after:40}));
  C.push(P('Fatimah Azeez Rawdhan: conceptualization, methodology, software, investigation, formal analysis, data curation, visualization, writing — original draft. Sarmad K. Ibrahim: conceptualization, methodology, formal analysis, validation, supervision, writing — review and editing, project administration. Both authors read and approved the final manuscript.'));
  C.push(P('Data and code availability. ',{bold:true,after:40}));
  C.push(P('This study analyses two publicly available measurement corpora, cited in the reference list, which the authors did not collect. The analysis code, the derived per-replicate records and the scripts that regenerate every table and figure are available at [repository URL]. No new measurement data were generated.'));
  C.push(P('Ethics approval. ',{bold:true,after:40}));
  C.push(P('Not applicable. The study involves no human participants and no personally identifying data.'));
  C.push(new Paragraph({children:[new PageBreak()]}));
  return C;
}

// Springer numbered style: Surname, Initials.: Title. Journal vol(issue), pages (year). https://doi.org/...
function springerRef(n,t){
  return new Paragraph({spacing:{after:70,line:264},indent:{left:520,hanging:520},
    alignment:AlignmentType.LEFT,
    children:[new TextRun({text:`${n}. ${t}`,font:'Times New Roman',size:20})]});
}

module.exports={titlePage,springerRef,P,HEAD};
