// Manuscript v2 — part B: experimental design, results, discussion, proofs, references.
const A=require('./part_a.js');
const {P,H1,H2,EQ,NUM,BUL,STMT,PROOF,table}=A;
const {Paragraph,TextRun,AlignmentType,PageBreak}=require('docx');
const REF=t=>new Paragraph({spacing:{after:70,line:264},indent:{left:460,hanging:460},
 alignment:AlignmentType.LEFT,children:[new TextRun({text:t,font:'Times New Roman',size:20})]});
const {figure,FIGURES}=require('./figures.js');
const C=[];

C.push(new Paragraph({children:[new PageBreak()]}));
C.push(H1('5. Experimental design'));
C.push(H2('5.1 Corpora and quality control'));
C.push(P('We use two public corpora recorded by the same measurement programme, so that every result is reported twice on independent data. The 4G corpus holds 135 traces at 1 Hz across five mobility classes; the 5G corpus holds 83 traces across driving and static conditions and three applications, with a network-mode field that distinguishes 5G, LTE and legacy rows. Both report serving RSRP, RSRQ, SNR and CQI, neighbour RSRP and RSRQ, measured downlink throughput, speed and serving cell identity.'));
C.push(P('Neighbour reporting is sparse and partly implausible in both corpora, and since the counterfactual action is defined by the neighbour measurement these rows cannot be dropped silently. A pre-registered plausibility filter keeps rows whose serving and neighbour RSRP lie in the 3GPP reporting range and whose A3 margin is within 25 dB, retaining 92,126 samples from 132 traces on 4G (52.8%) and 144,333 from 83 traces on 5G (76.5%). In the retained subsets the neighbour is the stronger cell in 40.2% and 33.4% of samples.'));
C.push(H2('5.2 Why not application throughput'));
C.push(P('The natural reward is the throughput the user receives, and the data reject it. On the 4G corpus the correlation between serving RSRP and log throughput is 0.08, and a gradient-boosted throughput model validated across traces retains explanatory power only through between-trace differences: within a session, application throughput is governed by transport and server behaviour that a handover cannot change. Auditing certificates against such a model would mean auditing them against noise. We therefore evaluate a radio-level indicator and state the limitation directly: the certified quantity is radio quality, not end-user throughput. The cost of a handover, however, remains calibrated from measured throughput, so the trade-off being certified keeps one foot in the application layer.'));
C.push(H2('5.3 Reward construction and cost calibration'));
C.push(P('A gradient-boosted model maps (RSRP, RSRQ) to SINR with grouped cross-validation over traces, attaining R2 = 0.759 on 4G and 0.448 on 5G; applied to the neighbour measurements it estimates the SINR the user would have seen after a handover. The estimate is quantised to a CQI index through standard SINR thresholds and mapped to spectral efficiency through the 3GPP CQI table, neither of which is fitted to the data. The lower 5G figure reflects a mixture of radio access technologies within a trace and is reported as a limit on the realism of that environment, not on the internal validity of the audit, since the oracle defines the reward by construction.'));
C.push(P('The interruption cost is measured rather than assumed. Across 2,292 real cell changes in the 4G corpus the median throughput in the two seconds after a change is 0.957 of the preceding six seconds, giving a cost of 0.043. The 5G corpus gives 0.232 for changes that keep the radio access technology and 0.432 for those that also change it, which account for 39% of its cell changes: in a non-standalone deployment a handover that drops the user to the anchor technology costs roughly twice as much as one that does not.'));
C.push(H2('5.4 Oracle construction, and two pitfalls'));
C.push(P('Because the environment is trace-driven, the exact value of any policy is computable, and this is what allows coverage to be audited. Constructing it correctly is less obvious than it appears, and in developing this study we made two errors, each of which produced an apparent certificate failure larger than the effects under study. We report them because any semi-synthetic benchmark in this area is exposed to both.'));
C.push(P('First, the SINR-to-efficiency map is a step function, so the expected reward is not the map applied to the expected SINR. Using the point-mapped value shifted each cell value by 0.023, roughly twenty times the policy gaps being measured, and produced coverage of 0.35 where the estimator was in fact unbiased. Second, the interruption cost and the clipping of the reward at zero were applied outside the expectation rather than inside it, which reintroduced a bias of 6 x 10^-4 against gaps of the same order and produced coverage of 0.55. The correct oracle is a Monte Carlo average of exactly the reward that is drawn, cost and clipping included; we use 400 draws per cell. After the correction the measured bias is 2.2 x 10^-4 at most across the 24 cells in which truncation never activates, which is the prediction of Lemma 1.'));
C.push(P('A third pitfall concerns the audit rather than the oracle. Proposition 1 predicts zero bias where no weight is truncated, and testing that by selecting the replicates in which no large weight happened to appear gives 1.8 x 10^-2, two orders of magnitude above the truth: conditioning on the absence of the tail event is itself a selection. The predicate must be evaluated on cells where truncation never activates, not on replicates that avoided it.'));
C.push(H2('5.5 Protocol'));
C.push(P('The incumbent is a softened A3 rule whose temperature controls how much exploration the logs contain. We sweep the temperature over {0.2, 0.4, 0.8, 1.2, 2.0}, the log size over {1, 5, 20} thousand decisions and four candidate policies spanning conservative to deliberately extreme settings, giving 60 operating points per corpus, each evaluated on 500 independently drawn logs. Coverage is reported with Wilson intervals, so no coverage figure appears in this paper without the uncertainty attached to it.'));

C.push(new Paragraph({children:[new PageBreak()]}));
C.push(H1('6. Results'));
C.push(H2('6.1 The benign regime'));
C.push(P('Where the incumbent explores and the candidate is not far from it, screening behaves as the literature assumes. At temperature 1.2 and above with twenty thousand logged decisions, the Student-t certificate on the doubly-robust estimator covers at its nominal level, accepts the genuinely better candidates in 99.7% of logs on 4G and 100% on 5G, and never accepts the harmful one. The measured bias is at most 2.2 x 10^-4 where truncation never activates. This is a positive result and not a vacuous one: it establishes that counterfactual screening of handover policies is feasible on real logs at sample sizes an operator can collect.'));
C.push(H2('6.2 Where the certificate fails'));
C.push(P('Of the 60 operating points, 25 on 4G and 21 on 5G fall below nominal coverage, and the worst reach 0.000 with a Wilson interval of [0.000, 0.008]. Two features of the failure matter more than its existence.'));
C.push(...table([2300,2000,1900,1900,1900],[
['Logged decisions','Coverage (4G)','Coverage (5G)','ESS (4G)','Max weight (4G)'],
['1,000','0.358','0.310','827','33'],
['5,000','0.164','0.038','2,899','201'],
['20,000','0.014','0.000','15,980','3,890']],
'Table 1. Coverage degrades as logged data accumulate (incumbent temperature 0.2, aggressive candidate, nominal 0.95, 500 logs per row). The effective sample size rises in proportion to the log and indicates no problem at any row.'));
C.push(P('The first feature is the direction of the trend. The truncation bias does not shrink with n while the confidence interval shrinks as n^-1/2, so the certificate becomes more confident about a wrong value: an operator who responds to a borderline screening result by collecting more data makes the certificate worse. The second concerns the diagnostic. At the worst 4G point the effective sample size is 2,899 of 5,000 and on 5G 14,934 of 20,000, both of which read as unproblematic overlap, while coverage is zero.'));
C.push(...figure(...FIGURES.fig1));
C.push(P('We decomposed the error into two mechanisms that dominate in different regimes. The reported standard error divided by the true spread of the estimate across logs is 0.57 at one thousand decisions and 0.92 at twenty thousand: under heavy tails the empirical variance misses the tail in a short log, and the operator error bar is too small in 84% of logs. The ratio of bias to spread moves in the opposite direction, from 0.26 to 1.08. Variance underestimation dominates at small n and truncation bias at large n, which is why coverage is not monotone for every candidate.'));
C.push(...figure(...FIGURES.fig2));
C.push(H2('6.3 Comparison of certificates'));
C.push(...table([3400,2400,3100],[
['Certificate','Worst-case coverage (4G)','Power in the benign regime'],
['Doubly robust + Student-t','0.000 [0.000, 0.008]','0.997'],
['+ sampled charge, Student-t','0.23','0.997'],
['+ sampled charge, Catoni','0.25','near full'],
['+ sampled charge, median of means','0.82','almost none'],
['+ sampled charge, empirical Bernstein','0.99','0.000'],
['+ closed-form charge, Student-t (proposed)','0.926 [0.900, 0.946]','0.997'],
['+ closed-form charge, empirical Bernstein','1.000','0.000']],
'Table 2. Worst-case coverage over 60 operating points against power where the candidate is genuinely better, 500 logs per point. The 5G corpus gives 0.936 [0.911, 0.954] for the proposed certificate with power 1.000.'));
C.push(P('The proposed certificate lifts worst-case coverage from 0.000 to 0.926 on 4G and 0.936 on 5G while its acceptance rate is identical to the uncorrected certificate wherever the candidate is genuinely better. Validity is recovered at no measurable cost in power, which is the central quantitative claim of this paper. Two qualifications belong with it. On 4G a single cell of 60 has its whole Wilson interval below nominal, at temperature 0.8 with one thousand decisions, where the charge is zero and the maximum weight is 2.6: that residual gap is the small-sample behaviour of an asymptotic bound, not a truncation effect, and on 5G no cell is below nominal. And the empirical-Bernstein variant, now applied under an assumption that genuinely holds, attains coverage 1.000 with zero power, which shows that bounded-range finite-sample bounds remain too wide at these effect sizes rather than being wrong.'));
C.push(H2('6.4 The estimator family'));
C.push(...figure(...FIGURES.fig3));
C.push(...table([2200,1500,1500,1500,1500,1500],[
['Estimator','Worst cov. 4G','charged','Worst cov. 5G','charged','Mean charge'],
['Inverse propensity scoring','0.952','0.952','0.948','0.948','0.061 / 0.073'],
['Self-normalised','0.000','0.936','0.000','0.952','0.061 / 0.073'],
['Doubly robust','0.000','0.944','0.000','0.940','0.061 / 0.073'],
['Switch-DR','0.000','0.944','0.000','0.948','0.102 / 0.120'],
['Optimistic shrinkage','0.000','1.000','0.000','1.000','0.194 / 0.216']],
'Table 3. Theorem 3 applied across the published estimator family on both corpora, 250 logs per cell. Every estimator that distorts the weight fails without the charge and is repaired by it; the charge column gives the mean price the certificate pays, 4G / 5G.'));
C.push(P('One correction repairs the family, and it does so identically on two independent corpora. The charge also ranks the transforms, and the ranking is not the estimation-error ranking. Hard truncation charges 0.061 on 4G and 0.073 on 5G; switching charges roughly twice that; continuous shrinkage charges 0.194 and 0.216 because it distorts every weight rather than only the tail. The consequence is stark: shrinkage has the highest uncorrected acceptance rate in the table, 1.000 on both corpora, and once charged it accepts nothing at all. A transform selected for mean squared error is not necessarily a transform one can certify with, and the charge is the quantity that decides which is which.'));
C.push(...figure(...FIGURES.fig5));
C.push(H2('6.5 The certifiability frontier'));
C.push(...figure(...FIGURES.fig4));
C.push(P('Because the charge depends only on the two policies, the frontier Delta = 2 r_max cbar is computable in advance. Measured over a grid of candidate settings, the fraction that are certifiable rises with the exploration the incumbent retains: at temperature 0.2, 11% of settings have a positive gain and none are certifiable; at 0.8, 31% are positive and 19% certifiable; at 2.0, 58% are positive and all of them are certifiable. The largest hysteresis distance that can be certified grows from 1 dB to 3 dB over the same range. Validated against the realised gate on 40 settings with 60 logs each, the prediction agrees in 97.5% of settings on both corpora.'));
C.push(H2('6.6 Which diagnostic predicts failure'));
C.push(...table([2600,2000,2000,2200],[
['Diagnostic','Separates (4G)','Balanced accuracy (4G)','Balanced accuracy (5G)'],
['Effective sample size','no','—','—'],
['Maximum importance weight','no','0.940','0.957'],
['Charge cbar','yes','1.000','0.957']],
'Table 4. Ability of a single threshold to separate cells whose coverage is below nominal from those clearly above it.'));
C.push(P('The effective sample size never separates on either corpus. The charge separates perfectly on 4G and ties the maximum weight on 5G, and unlike either alternative it is motivated rather than heuristic: it is the bias bound itself, and it is available before the log is collected. We therefore key the abstention branch of the gate to the charge, while noting that on 5G no single threshold on any of the three quantities is perfect.'));
C.push(H2('6.7 Deployment-regime shift'));
C.push(...figure(...FIGURES.fig6));
C.push(...table([2600,2100,2100,2000],[
['Audited against','4G','5G','Remedy'],
['Logging regime (src = dst)','0.803','0.813','charge raises to 0.978 / 0.967'],
['Deployment regime (src ≠ dst)','0.587','0.521','charge raises only to 0.723 / 0.648']],
'Table 5. Mean coverage when the certificate computed on logs from one mobility regime is audited against the truth in the regime where the policy is deployed.'));
C.push(P('An operator tunes on one part of the network and deploys on another, and the certificate does not travel. Within a regime the charged certificate is at or above its nominal level on both corpora; across regimes it loses roughly a quarter of its coverage on 4G and a third on 5G, and the charge repairs only part of the gap. The failure is of a different kind from the one Theorem 3 addresses: it is a shift in the context distribution rather than a distortion of the weight, and our correction is not designed for it. We state it as an open problem, with the practical recommendation that certificates be computed per regime and not transported.'));
C.push(H2('6.8 Monitoring'));
C.push(...table([1600,2100,2100,2100],[
['Truncation M','Fixed-n, monitored (4G / 5G)','Confidence sequence (4G / 5G)','CS acceptance (4G / 5G)'],
['20','0.677 / 0.613','1.000 / 1.000','0.000 / 0.394'],
['5','0.677 / 0.613','1.000 / 1.000','0.500 / 0.600'],
['2','0.677 / 0.613','1.000 / 1.000','0.629 / 0.606']],
'Table 6. Worst-case coverage under monitoring at 25 checkpoints, and the acceptance rate of the betting confidence sequence where the candidate is genuinely better.'));
C.push(P('Evaluated once at a pre-specified sample size the fixed-n certificate covers at 0.935 on 4G and 0.903 on 5G; monitored at 25 checkpoints the same bound falls to 0.677 and 0.613. Optional stopping is therefore a failure mode in its own right, and it is the mode closest to how an operator actually behaves. The betting confidence sequence holds at 1.000 under the same monitoring on both corpora, as its construction guarantees.'));
C.push(P('Its power, however, is governed by the truncation level in a way the fixed-n certificate is not. At M = 20 the sequence accepts nothing on 4G and 39% of the time on 5G; at M = 2 it accepts 63% and 61% respectively, with coverage unchanged at 1.000. The width of a betting sequence scales with the a priori bound on the statistic, which Proposition 2 sets at M + 1, so the level that is best for a fixed-sample certificate is far from the level that is best for an anytime-valid one. Anytime validity is affordable here, but only at a truncation level an order of magnitude tighter than the conventional choice.'));
C.push(...figure(...FIGURES.fig8));
C.push(H2('6.9 The sequential horizon'));
C.push(...table([1500,1700,1700,1700,1700],[
['Window k','4G bias','4G cov. / acc.','5G bias','5G cov. / acc.'],
['1','−0.0102','0.967 / 1.00','+0.1377','0.000 / 1.00'],
['2','−0.0311','1.000 / 0.22','+0.1024','0.000 / 1.00'],
['3','−0.0323','1.000 / 0.13','+0.0850','0.017 / 1.00'],
['5','−0.0385','1.000 / 0.05','+0.0579','0.650 / 0.98'],
['10','−0.0786','1.000 / 0.00','−0.0160','1.000 / 0.10'],
['40 (full)','−0.3837','1.000 / 0.00','−0.4901','1.000 / 0.00']],
'Table 7. Windowed per-decision importance sampling at horizon 40, incumbent temperature 1.2, conservative candidate (true gain +0.049 on 4G, +0.078 on 5G).'));
C.push(P('Full per-decision importance sampling is valid and useless at this horizon on both corpora: it accepts nothing. Shortening the window restores acceptance, and on the 4G corpus it does so safely, since the bias is downward, which is the conservative direction for a lower bound. On the 5G corpus it does not. There the bias at short windows is upward and large, the certificate covers at 0.000 while accepting in every run, and only at k = 10 does validity return, by which point acceptance has collapsed to 0.10. Counting across all cells, five of eighteen show an upward bias at k = 1 on 4G, against six or seven at every window below ten on 5G.'));
C.push(P('We therefore do not recommend a window length. The windowed estimator recovers power, and whether it does so safely depends on the mixing of the induced chain, which differs between the two networks and is not something the operator can read off the logs. Proposition 8 bounds the bias but does not sign it, and our measurements show both signs occurring. For sequential screening the honest position is that no estimator we tested is simultaneously valid and useful on both corpora, and that this remains the principal open problem of the paper.'));
C.push(...figure(...FIGURES.fig7));

C.push(H1('7. Discussion and limitations'));
C.push(P('The operational reading is threefold. A screening gate should carry an abstention branch keyed to the charge rather than to the effective sample size. The charge should be computed before logs are collected, since it bounds what can be certified and therefore constrains how much exploration the incumbent must retain. And collecting more data is not a remedy for weak overlap; it is what turns a wide, honest interval into a narrow, wrong one.'));
C.push(P('The limitations are as follows. The logging policy is superimposed on real measurements rather than logged with real propensities, because no public trace records them; this is the standard supervised-to-bandit conversion and it is an assumption, not a property of the data. The certified quantity is radio quality rather than end-user throughput, for the reason given in Section 5.2. The oracle inherits the error of the SINR model, which is substantially larger on the 5G corpus; the audit remains internally valid because the oracle defines the reward, but the 5G environment is a less faithful model of a real network than the 4G one. The action space is binary because the traces report one neighbour per sample, and the policy class is one-dimensional. Finally, the deployment-shift failure of Section 6.7 and the power of anytime-valid certificates are open problems to which we offer measurements rather than solutions.'));

C.push(H1('8. Conclusion'));
C.push(P('Counterfactual screening is the only way to decide on an autonomously proposed network policy without experimenting on users, and on real logs it works where the incumbent explores and the candidate stays close to it. Outside that regime the certificate that is supposed to make the decision safe can be wrong in every run, grows more confident with more data, and is not flagged by the diagnostic in common use. The truncation bias responsible has an exact identity, and the correction it licenses must be charged through its conditional expectation; charged that way it is bounded by construction, repairs the published estimator family as a single statement, recovers validity at no cost in power on two independent corpora, and tells an operator in advance which candidates are worth screening at all.'));

C.push(new Paragraph({children:[new PageBreak()]}));
C.push(H1('Appendix A. Proofs'));
C.push(P('Lemma 1.',{bold:true,after:60}));
C.push(PROOF('Condition on X and on the cross-fitted model, which by (A3) is independent of the sample in question. The expectation of the second term is E_A[ ( w - 1 )( R - qhat ) ] = Sum_a pi0(a|x) ( pi(a|x)/pi0(a|x) - 1 )( q(x,a) - qhat(x,a) ) = Sum_a ( pi(a|x) - pi0(a|x) )( q(x,a) - qhat(x,a) ), where q is the true outcome function. Adding the first term, Sum_a ( pi - pi0 ) qhat, gives Sum_a ( pi - pi0 ) q(x,a), whose expectation over X is V(pi) - V(pi0) = Delta.'));
C.push(P('Proposition 1.',{bold:true,after:60}));
C.push(PROOF('The truncated and untruncated contributions differ only in the weight, so their difference is ( w_M - w )( R - qhat ) = - ( w - M )_+ ( R - qhat ) pathwise. Taking expectations and applying Lemma 1 gives the identity. The bound follows from (A2), since | R - qhat | <= r_max; subtracting r_max ( w - M )_+ therefore makes the expectation no larger than Delta.'));
C.push(P('Proposition 2.',{bold:true,after:60}));
C.push(PROOF('For each a with pi0(a|x) > 0, pi0 ( pi/pi0 - M )_+ = ( pi - M pi0 )_+ by positive homogeneity of the positive part; summing over a gives the identity, and the left side is the conditional expectation of ( w - M )_+ given X = x, which is (i) and (iii) by the tower property and the conditional Jensen inequality for the variance. For (ii), each summand satisfies 0 <= ( pi - M pi0 )_+ <= pi, so the sum lies in [0, Sum_a pi] = [0, 1]. For (iv), ( pi - M pi0 )_+ tends to pi as pi0 tends to zero with pi fixed, which is finite.'));
C.push(P('Theorem 3.',{bold:true,after:60}));
C.push(PROOF('Replacing w_M by phi(w) in the argument of Proposition 1 gives the identity with ( phi(w) - w ) in place of ( w_M - w ). Conditionally on X, | E_A[ ( phi(w) - w )( R - qhat ) ] | <= r_max Sum_a pi0 | phi( pi/pi0 ) - pi/pi0 | = r_max Sum_a | pi0 phi( pi/pi0 ) - pi | = r_max c_phi(x). Taking expectations over X and applying (A2) gives the claim; for phi(w) = min(w, M) we have pi0 phi = min( pi, M pi0 ), so c_phi = Sum_a ( pi - M pi0 )_+, which is Proposition 2.'));
C.push(P('Theorem 5.',{bold:true,after:60}));
C.push(PROOF('(i) The upper bound is Proposition 1 together with the non-negativity of the charge; the lower bound follows since the bias term is at least - r_max cbar and the charge subtracts at most r_max cbar. (ii) If Delta > 2 r_max cbar then the charged mean is strictly positive by (i), and since the contribution is bounded by Proposition 2(ii), any consistent lower bound converges to that mean, so there is n0 beyond which it is positive except on an event of probability delta. (iii) Validity of the certificate gives acceptance probability at most delta whenever Delta <= 0.'));
C.push(P('Proposition 6.',{bold:true,after:60}));
C.push(PROOF('Apply the single-policy certificate at level delta/|G| to each member of G and take a union bound over the |G| events of individual failure; the intersection of the complements has probability at least 1 - delta and contains the event that the bound reported for the selected member is valid, whichever member is selected. The width statement follows from the sub-Gaussian quantile scaling as sqrt( 2 log( |G| / delta ) ).'));
C.push(P('Proposition 8.',{bold:true,after:60}));
C.push(PROOF('Write the per-decision estimator as a sum over steps of rewards weighted by the full history ratio and the windowed estimator as the same sum with the ratio truncated to the last k steps. The difference at step t is bounded by r_max times the total variation between the occupancy induced by the full history and by its k-step truncation, and summing over the horizon gives the stated bound. One-sidedness requires that the truncation can only under-weight the candidate occupancy, which does not hold in general; Section 6.8 reports the measured sign.'));

C.push(H1('Appendix B. Reproducibility'));
C.push(P('All results are produced by a released package and six experiment scripts that run on a CPU runtime. Each experiment is seeded per replicate and writes raw per-replicate records alongside its summary, so any table can be recomputed without rerunning simulations. Ten identity tests check the propositions numerically: the closed-form charge matches the conditional expectation of the sampled charge to 10^-10, the charge is bounded, it tends to the candidate probability under deficient support, Theorem 3 reduces to Proposition 2 under hard truncation, and the confidence sequence is not violated at any checkpoint under heavy-tailed data. Every claim in the abstract is restated as a pass/fail predicate evaluated by a single script, whose output is included in the release.'));

C.push(new Paragraph({children:[new PageBreak()]}));
C.push(H1('References'));
C.push(P('Entries marked [v] were verified against the publisher record during preparation; the remainder carry the details we hold and must be confirmed before submission. Preprints are marked as such.',{size:19,italics:true,after:180}));
const {ENTRIES}=require('./references.js');
ENTRIES.forEach((t,i)=>C.push(REF('['+(i+1)+'] '+t)));

module.exports={C};
