// Reference list. The tag at the end of each entry records its verification status:
//   [v]  verified against the publisher record or an authoritative index during preparation
//   [p]  preprint, verified on arXiv (no journal reference at the time of checking)
//   [?]  details we hold but could not confirm from an accessible record; confirm before submission
const {Paragraph,TextRun,AlignmentType}=require('docx');
const REF=t=>new Paragraph({spacing:{after:70,line:264},indent:{left:460,hanging:460},
 alignment:AlignmentType.LEFT,children:[new TextRun({text:t,font:'Times New Roman',size:20})]});

const ENTRIES=[
// --- counterfactual and off-policy evaluation
'D. G. Horvitz, D. J. Thompson, "A generalization of sampling without replacement from a finite universe," Journal of the American Statistical Association, vol. 47, no. 260, pp. 663–685, 1952. doi:10.1080/01621459.1952.10483446  [v]',
'J. M. Robins, A. Rotnitzky, L. P. Zhao, "Estimation of regression coefficients when some regressors are not always observed," Journal of the American Statistical Association, vol. 89, no. 427, pp. 846–866, 1994.  [v]',
'D. Precup, R. S. Sutton, S. Singh, "Eligibility traces for off-policy policy evaluation," in Proc. 17th Int. Conf. Machine Learning (ICML), 2000, pp. 759–766.  [v]',
'E. L. Ionides, "Truncated importance sampling," Journal of Computational and Graphical Statistics, vol. 17, no. 2, pp. 295–311, 2008. doi:10.1198/106186008X320456  [v]',
'A. Strehl, J. Langford, L. Li, S. M. Kakade, "Learning from logged implicit exploration data," in Advances in Neural Information Processing Systems (NeurIPS), 2010, pp. 2217–2225.  [v]',
'L. Li, W. Chu, J. Langford, X. Wang, "Unbiased offline evaluation of contextual-bandit-based news article recommendation algorithms," in Proc. 4th ACM Int. Conf. Web Search and Data Mining (WSDM), Hong Kong, 2011. doi:10.1145/1935826.1935878  [v]',
'M. Dudík, J. Langford, L. Li, "Doubly robust policy evaluation and learning," in Proc. 28th Int. Conf. Machine Learning (ICML), Bellevue, WA, 2011, pp. 1097–1104.  [v]',
'L. Bottou, J. Peters, J. Quiñonero-Candela, D. X. Charles, D. M. Chickering, E. Portugaly, D. Ray, P. Simard, E. Snelson, "Counterfactual reasoning and learning systems: the example of computational advertising," Journal of Machine Learning Research, vol. 14, no. 101, pp. 3207–3260, 2013.  [v]',
'A. Swaminathan, T. Joachims, "The self-normalized estimator for counterfactual learning," in Advances in Neural Information Processing Systems (NeurIPS), 2015, pp. 3231–3239.  [v]',
'P. S. Thomas, G. Theocharous, M. Ghavamzadeh, "High-confidence off-policy evaluation," in Proc. AAAI Conf. Artificial Intelligence, vol. 29, no. 1, 2015. doi:10.1609/aaai.v29i1.9541  [v]',
'P. S. Thomas, G. Theocharous, M. Ghavamzadeh, "High-confidence policy improvement," in Proc. 32nd Int. Conf. Machine Learning (ICML), PMLR vol. 37, 2015, pp. 2380–2388.  [v]',
'N. Jiang, L. Li, "Doubly robust off-policy value evaluation for reinforcement learning," in Proc. 33rd Int. Conf. Machine Learning (ICML), PMLR vol. 48, 2016, pp. 652–661.  [v]',
'Y.-X. Wang, A. Agarwal, M. Dudík, "Optimal and adaptive off-policy evaluation in contextual bandits," in Proc. 34th Int. Conf. Machine Learning (ICML), PMLR vol. 70, 2017, pp. 3589–3597.  [v]',
'T. Joachims, A. Swaminathan, M. de Rijke, "Deep learning with logged bandit feedback," in Proc. Int. Conf. Learning Representations (ICLR), 2018.  [v]',
'M. Farajtabar, Y. Chow, M. Ghavamzadeh, "More robust doubly robust off-policy evaluation," in Proc. 35th Int. Conf. Machine Learning (ICML), PMLR vol. 80, 2018, pp. 1447–1456.  [v]',
'R. Laroche, P. Trichelair, R. Tachet des Combes, "Safe policy improvement with baseline bootstrapping," in Proc. 36th Int. Conf. Machine Learning (ICML), PMLR vol. 97, 2019, pp. 3652–3661.  [v]',
'N. Kallus, M. Uehara, "Double reinforcement learning for efficient off-policy evaluation in Markov decision processes," Journal of Machine Learning Research, vol. 21, no. 167, pp. 1–63, 2020.  [v]',
'Y. Su, M. Dimakopoulou, A. Krishnamurthy, M. Dudík, "Doubly robust off-policy evaluation with shrinkage," in Proc. 37th Int. Conf. Machine Learning (ICML), PMLR vol. 119, 2020, pp. 9167–9176.  [v]',
'N. Sachdeva, Y. Su, T. Joachims, "Off-policy bandits with deficient support," in Proc. 26th ACM SIGKDD Conf. Knowledge Discovery and Data Mining (KDD), 2020. doi:10.1145/3394486.3403139  [v]',
'A. M. Metelli, M. Papini, N. Montali, M. Restelli, "Importance sampling techniques for policy optimization," Journal of Machine Learning Research, vol. 21, pp. 1–75, 2020.  [v]',
// --- concentration, heavy tails, anytime-valid inference
'E. B. Wilson, "Probable inference, the law of succession, and statistical inference," Journal of the American Statistical Association, vol. 22, no. 158, pp. 209–212, 1927. doi:10.1080/01621459.1927.10502953  [v]',
'J. Ville, Étude critique de la notion de collectif. Paris: Gauthier-Villars, 1939.  [?]',
'B. Efron, "Better bootstrap confidence intervals," Journal of the American Statistical Association, vol. 82, no. 397, pp. 171–185, 1987. doi:10.1080/01621459.1987.10478410  [v]',
'A. Maurer, M. Pontil, "Empirical Bernstein bounds and sample-variance penalization," in Proc. Conf. Learning Theory (COLT), 2009. arXiv:0907.3740  [v]',
'O. Catoni, "Challenging the empirical mean and empirical variance: a deviation study," Annales de l\'Institut Henri Poincaré (B) Probabilités et Statistiques, vol. 48, no. 4, pp. 1148–1185, 2012. doi:10.1214/11-AIHP454  [v]',
'G. Lugosi, S. Mendelson, "Mean estimation and regression under heavy-tailed distributions: a survey," Foundations of Computational Mathematics, vol. 19, no. 5, pp. 1145–1190, 2019. doi:10.1007/s10208-019-09427-x  [v]',
'S. R. Howard, A. Ramdas, J. McAuliffe, J. Sekhon, "Time-uniform Chernoff bounds via nonnegative supermartingales," Probability Surveys, vol. 17, pp. 257–317, 2020. doi:10.1214/18-PS321  [v]',
'A. Ramdas, P. Grünwald, V. Vovk, G. Shafer, "Game-theoretic statistics and safe anytime-valid inference," Statistical Science, vol. 38, no. 4, pp. 576–601, 2023. doi:10.1214/23-STS894  [v]',
'I. Waudby-Smith, A. Ramdas, "Estimating means of bounded random variables by betting," Journal of the Royal Statistical Society Series B: Statistical Methodology, vol. 86, no. 1, pp. 1–27, 2024. doi:10.1093/jrsssb/qkad009  [v]',
'S. Bates, A. N. Angelopoulos, L. Lei, J. Malik, M. I. Jordan, "Distribution-free, risk-controlling prediction sets," Journal of the ACM, vol. 68, no. 6, pp. 1–34, 2021. doi:10.1145/3478535  [v]',
'A. N. Angelopoulos, S. Bates, E. J. Candès, M. I. Jordan, L. Lei, "Learn then test: calibrating predictive algorithms to achieve risk control," arXiv:2110.01052v5, 2022.  [p]',
'I. Gibbs, E. J. Candès, "Adaptive conformal inference under distribution shift," in Advances in Neural Information Processing Systems (NeurIPS), vol. 34, 2021.  [v]',
// --- uncertainty quantification in wireless systems
'K. M. Cohen, S. Park, O. Simeone, P. Popovski, S. Shamai (Shitz), "Guaranteed dynamic scheduling of ultra-reliable low-latency traffic via conformal prediction," IEEE Signal Processing Letters, vol. 30, pp. 473–477, 2023. doi:10.1109/LSP.2023.3264939  [v]',
'M. Zecchin, S. Park, O. Simeone, "Forking uncertainties: reliable prediction and model predictive control with sequence models via conformal risk control," IEEE Journal on Selected Areas in Information Theory, vol. 5, pp. 44–61, 2024. doi:10.1109/JSAIT.2024.3368229  [v]',
'O. Simeone, S. Park, M. Zecchin, "Conformal calibration: ensuring the reliability of black-box AI in wireless systems," arXiv:2504.09310v3, 2025.  [p]',
'F. Binucci, O. Simeone, P. Banelli, "Conformal Lyapunov optimization: optimal resource allocation under deterministic reliability constraints," arXiv:2503.00486v5, 2025.  [p]',
// --- handover control, self-organizing networks, O-RAN
'M. S. Mollel, A. I. Abubakar, M. Ozturk, S. F. Kaijage, M. Kisangiri, S. Hussain, M. A. Imran, Q. H. Abbasi, "A survey of machine learning applications to handover management in 5G and beyond," IEEE Access, vol. 9, pp. 45770–45802, 2021. doi:10.1109/ACCESS.2021.3067503  [v]',
'M. Polese, L. Bonati, S. D\'Oro, S. Basagni, T. Melodia, "Understanding O-RAN: architecture, interfaces, algorithms, security, and research challenges," IEEE Communications Surveys & Tutorials, vol. 25, no. 2, pp. 1376–1411, 2023. doi:10.1109/COMST.2023.3239220  [v]',
'O-RAN Alliance, O-RAN Architecture Description, O-RAN.WG1.OAD, Work Group 1 (Use Cases and Overall Architecture). Cite the release in force at submission.  [?]',
'3GPP, Evolved Universal Terrestrial Radio Access (E-UTRA); Physical layer procedures, TS 36.213 (CQI table 7.2.3-1). Cite the release used.  [?]',
'3GPP, Evolved Universal Terrestrial Radio Access (E-UTRA); Radio Resource Control (RRC); Protocol specification, TS 36.331 (measurement event A3). Cite the release used.  [?]',
'3GPP, NR; Radio Resource Control (RRC); Protocol specification, TS 38.331. Cite the release used.  [?]',
// --- measurement corpora
'D. Raca, J. J. Quinlan, A. H. Zahran, C. J. Sreenan, "Beyond throughput: a 4G LTE dataset with channel and context metrics," in Proc. 9th ACM Multimedia Systems Conf. (MMSys), 2018, pp. 460–465. doi:10.1145/3204949.3208123  [v]',
'D. Raca, D. Leahy, C. J. Sreenan, J. J. Quinlan, "Beyond throughput, the next generation: a 5G dataset with channel and context metrics," in Proc. 11th ACM Multimedia Systems Conf. (MMSys), Istanbul, Turkey, June 2020. doi:10.1145/3339825.3394938 (page range to be taken from the ACM record; this is the citation the dataset repository asks for)  [?]',
'A. Narayanan, E. Ramadan, R. Mehta, X. Hu, Q. Liu, R. A. K. Fezeu, U. K. Dayalan, S. Verma, P. Ji, T. Li, F. Qian, Z.-L. Zhang, "Lumos5G: mapping and predicting commercial mmWave 5G throughput," in Proc. ACM Internet Measurement Conf. (IMC), 2020, pp. 176–193. doi:10.1145/3419394.3423629  [v]',
// --- author prior work
'S. A. Abdulhussien, S. K. Ibrahim, "Proactive orientation-aware reconfigurable intelligent surface reconfiguration via Attention-LSTM and direct phase computation," Physical Communication, vol. 77, art. no. 103171, 2026. doi:10.1016/j.phycom.2026.103171  [v]',
];

module.exports = {ENTRIES, REF};
