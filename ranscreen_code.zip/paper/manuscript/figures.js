// Figure insertion: places each PNG at its section with a numbered caption.
const fs=require('fs');
const {Paragraph,TextRun,ImageRun,AlignmentType}=require('docx');
const DIR='/mnt/user-data/outputs/figures';

// width in points (1 pt = 1/72 in); the text block is about 6.2 in wide at our margins
function figure(name, number, caption, widthIn=6.1){
  const png=`${DIR}/${name}.png`;
  if(!fs.existsSync(png)) return [];
  const buf=fs.readFileSync(png);
  // read the PNG header for the pixel dimensions, so the aspect ratio is preserved exactly
  const w=buf.readUInt32BE(16), h=buf.readUInt32BE(20);
  const wPt=widthIn*72, hPt=wPt*h/w;
  return [
    new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:200,after:60},
      children:[new ImageRun({data:buf,transformation:{width:Math.round(wPt),height:Math.round(hPt)}})]}),
    new Paragraph({alignment:AlignmentType.JUSTIFIED,spacing:{after:220,line:252},
      children:[new TextRun({text:`Fig. ${number}. ${caption}`,font:'Times New Roman',size:19,
        italics:true,color:'444444'})]}),
  ];
}

const FIGURES={
  fig1:['fig1_failure',1,'Certificate coverage of the standard doubly-robust bound, 4G corpus above and 5G below, with Wilson intervals over 500 logs per point and the nominal level dashed. (a) Coverage falls as the log grows under weak exploration. (b) Coverage against the exploration the incumbent retains at twenty thousand decisions. (c) Coverage against the mean maximum importance weight, coloured by effective sample size: the failure tracks the tail, while the effective sample size stays high throughout.'],
  fig2:['fig2_mechanisms',2,'Diagnostics and mechanisms. (a) The effective sample size does not separate failing from passing operating points on either corpus. (b) The charge does. (c) The two error sources, measured separately at incumbent temperature 0.2: the reported standard error divided by the true spread of the estimate (solid) and the absolute bias divided by the same spread (dashed). Variance underestimation dominates at small samples and truncation bias at large ones.'],
  fig3:['fig3_repair',3,'Worst-case coverage per candidate policy, standard certificate against the closed-form charge, on both corpora. The charge lifts every policy to or near the nominal level without altering acceptance where the candidate is genuinely better.'],
  fig4:['fig4_frontier',4,'The certifiability frontier. (a) True gain against twice the charge, which is computable before any log exists; the diagonal separates candidates that can eventually be certified from those that cannot. (b) The prediction against the realised acceptance rate of the gate over 40 settings with 60 logs each.'],
  fig5:['fig5_estimator_family',5,'Theorem 3 across the published estimator family: worst-case coverage, power where the candidate is genuinely better, and the mean charge each transform pays. Every estimator that distorts the weight is repaired by its charge, and the charge ranks the transforms in an order that differs from their estimation-error ranking.'],
  fig6:['fig6_transfer',6,'Coverage when a certificate computed on logs from one mobility regime is audited against the truth in the regime where the policy is deployed, without (a) and with (b) the closed-form charge. The diagonal is the within-regime case.'],
  fig7:['fig7_sequential',7,'Windowed per-decision importance sampling at the longest horizon: bias, coverage and acceptance against the window length k. Shortening the window restores power; whether it does so in the safe direction depends on the corpus.'],
  fig8:['fig8_anytime',8,'Monitoring at 25 checkpoints. Worst-case coverage of the fixed-sample bound against the betting confidence sequence, and the power of each, as a function of the truncation level. The level that is best for a fixed-sample certificate is far from the level that is best for an anytime-valid one.'],
};

module.exports={figure,FIGURES};
