// Build the Springer (JNSM) version: journal title page, body, Springer-numbered references.
const fs=require('fs');
const {Document,Packer,Paragraph,TextRun,AlignmentType,Footer,PageNumber,LevelFormat}=require('docx');
const A=require('./part_a.js');
const B=require('./part_b.js');
const {titlePage,springerRef}=require('./springer.js');
const {SPRINGER_ENTRIES}=require('./references_springer.js');

// The Elsevier front matter (title block, abstract, keywords) is the first block run in part A;
// for the Springer build we replace it with the journal's required title page.
const bodyA=A.C.slice(A.C.findIndex(p=>{
  try{return JSON.stringify(p).includes('1. Introduction');}catch(e){return false;}
}));

// part B ends with the Elsevier reference list; cut it at the References heading and re-add
const refIdx=B.C.findIndex(p=>{try{return JSON.stringify(p).includes('References');}catch(e){return false;}});
const bodyB=refIdx>0?B.C.slice(0,refIdx):B.C;

const cells=[...titlePage(),...bodyA,...bodyB];
cells.push(new Paragraph({spacing:{before:300,after:150},
  children:[new TextRun({text:'References',font:'Times New Roman',size:26,bold:true,color:'1F3864'})]}));
cells.push(new Paragraph({spacing:{after:180},
  children:[new TextRun({text:'Entries tagged [v] were verified against the publisher record during preparation; [p] marks preprints checked on arXiv; [?] marks details the authors must complete. Remove these tags before submission.',
  font:'Times New Roman',size:19,italics:true})]}));
SPRINGER_ENTRIES.forEach((t,i)=>cells.push(springerRef(i+1,t)));

const doc=new Document({
 numbering:{config:[
  {reference:'bul',levels:[{level:0,format:LevelFormat.BULLET,text:'•',alignment:AlignmentType.LEFT,
   style:{paragraph:{indent:{left:460,hanging:260}}}}]},
  {reference:'num',levels:[{level:0,format:LevelFormat.DECIMAL,text:'%1.',alignment:AlignmentType.LEFT,
   style:{paragraph:{indent:{left:460,hanging:260}}}}]}]},
 styles:{default:{document:{run:{font:'Times New Roman',size:22}}}},
 sections:[{properties:{page:{margin:{top:1400,bottom:1400,left:1400,right:1400}}},
  footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,
   children:[new TextRun({children:[PageNumber.CURRENT],font:'Times New Roman',size:18,color:'666666'})]})]})},
  children:cells}]});
Packer.toBuffer(doc).then(b=>{
 fs.writeFileSync('/mnt/user-data/outputs/Manuscript_Springer_JNSM.docx',b);
 console.log('springer build written,',cells.length,'blocks,',SPRINGER_ENTRIES.length,'references');
});
