const fs=require('fs');
const {Document,Packer,Paragraph,TextRun,AlignmentType,Footer,PageNumber,LevelFormat}=require('docx');
const A=require('./part_a.js');
const B=require('./part_b.js');
const cells=[...A.C,...B.C];
const doc=new Document({
 numbering:{config:[
  {reference:'bul',levels:[{level:0,format:LevelFormat.BULLET,text:'•',alignment:AlignmentType.LEFT,
   style:{paragraph:{indent:{left:460,hanging:260}}}}]},
  {reference:'num',levels:[{level:0,format:LevelFormat.DECIMAL,text:'%1.',alignment:AlignmentType.LEFT,
   style:{paragraph:{indent:{left:460,hanging:260}}}}]}]},
 styles:{default:{document:{run:{font:'Times New Roman',size:22}}}},
 sections:[{properties:{page:{margin:{top:1300,bottom:1300,left:1300,right:1300}}},
  footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,
   children:[new TextRun({children:[PageNumber.CURRENT],font:'Times New Roman',size:18,color:'666666'})]})]})},
  children:cells}]});
Packer.toBuffer(doc).then(b=>{
 fs.writeFileSync('/mnt/user-data/outputs/Manuscript_v2_Certified_Screening.docx',b);
 console.log('written,',cells.length,'blocks');
});
