// Submission package: highlights, cover letter, statements, and the checklist.
const fs=require('fs');
const {Document,Packer,Paragraph,TextRun,HeadingLevel,AlignmentType,Footer,PageNumber,LevelFormat,PageBreak}=require('docx');
const NAVY='1F3864';
const P=(t,o={})=>new Paragraph({alignment:o.align||AlignmentType.JUSTIFIED,
 spacing:{after:o.after===undefined?140:o.after,line:o.line||276},
 children:[new TextRun({text:t,font:'Times New Roman',size:o.size||22,bold:o.bold,italics:o.italics})]});
const H1=t=>new Paragraph({heading:HeadingLevel.HEADING_1,spacing:{before:280,after:150},
 children:[new TextRun({text:t,font:'Times New Roman',size:26,bold:true,color:NAVY})]});
const BUL=t=>new Paragraph({numbering:{reference:'b',level:0},spacing:{after:90,line:276},
 alignment:AlignmentType.JUSTIFIED,children:[new TextRun({text:t,font:'Times New Roman',size:22})]});
const C=[];

C.push(H1('Highlights'));
C.push(P('Five single-sentence statements, each under 85 characters as required by Elsevier.',{size:19,italics:true}));
C.push(BUL('Off-policy certificates for RAN control fail on real logs, with coverage as low as zero.'));
C.push(BUL('The failure deepens as logs grow and is invisible to the effective sample size.'));
C.push(BUL('An exact bias identity shows the correction must be charged in closed form.'));
C.push(BUL('The charge is bounded, repairs the estimator family, and costs no power.'));
C.push(BUL('It is computable before logging, so screenability is known in advance.'));

C.push(new Paragraph({children:[new PageBreak()]}));
C.push(H1('Cover letter'));
C.push(P('Dear Editor,'));
C.push(P('We submit for your consideration the manuscript "Certified counterfactual screening of AI-driven handover control policies in self-optimizing radio access networks".'));
C.push(P('Autonomous controllers are being placed in the configuration loop of radio access networks, and an operator must decide whether to deploy what they propose without experimenting on live users. Counterfactual evaluation answers that question from logged decisions, and the decision is licensed by a high-confidence lower bound that the literature treats as a guarantee. Our starting question is whether that guarantee actually holds on real network logs. It does not: across 60 operating points on two public measurement corpora, with 500 independent logs each, the standard certificate falls below its nominal level at 25 and 21 points respectively and reaches coverage 0.000 with a 95% interval of [0.000, 0.008]. Two properties of the failure invert operational intuition. It becomes more severe as the operator collects more data, because the bias is constant while the interval contracts. And it is invisible to the effective sample size, the diagnostic normally used to decide whether an off-policy estimate can be trusted.'));
C.push(P('We then prove an exact identity for the truncation bias and show that the correction it licenses must be charged through its conditional expectation rather than at the logged action. In closed form that charge requires no division, is bounded in the unit interval, is the Rao-Blackwell projection of the sampled correction, and remains finite where the logging policy has no support. Charging it this way lifts worst-case coverage from 0.000 to 0.926 and 0.936 on the two corpora with power unchanged, where the sampled form of the same correction reaches only 0.23. A generalisation to an arbitrary weight transform repairs the published estimator family as a single statement and shows that the transform with the smallest charge, not the smallest estimation error, is the one to certify with. Because the charge depends only on the two policies, it also yields a frontier that predicts screenability before any log exists, and matches the realised screening decision in 98% of settings.'));
C.push(P('We believe the work suits the journal for three reasons. The question is operational rather than methodological in origin: it is the question an operator faces before deploying anything an autonomous controller proposes. The evidence is measured on real traces from two generations of network rather than in simulation. And the contribution is a correction that practitioners can apply to the estimator they already use, together with a diagnostic that tells them in advance when screening is hopeless.'));
C.push(P('We also report what did not work. A certified adaptive-truncation rule, which we expected to resolve the validity and power tension, degrades both. The certificate remains valid for the logging regime and not for the deployment regime under mobility shift, and our correction does not repair that. Anytime-valid certificates hold under continuous monitoring but accept nothing at the effect sizes present here. And we document two oracle-construction pitfalls that produced, in our own development, apparent certificate failures larger than the effects under study. These are stated in the paper rather than omitted, because each one bounds what the contribution claims.'));
C.push(P('The manuscript is original, is not under consideration elsewhere, and all authors have approved the submission. Code, raw per-replicate records and the figure set are released, and every claim in the abstract is restated in the paper as a pass or fail predicate evaluated by a script in that release.'));
C.push(P('Yours sincerely,'));
C.push(P('Sarmad K. Ibrahim, on behalf of the authors'));
C.push(P('Department of Computer Engineering and Artificial Intelligence, College of Engineering, Mustansiriyah University, Baghdad, Iraq',{size:20}));

C.push(new Paragraph({children:[new PageBreak()]}));
C.push(H1('Statements'));
C.push(P('CRediT author contributions.',{bold:true,after:60}));
C.push(P('Fatimah Azeez Rawdhan: Conceptualization, Methodology, Software, Investigation, Formal analysis, Data curation, Visualization, Writing - original draft. Sarmad K. Ibrahim: Conceptualization, Methodology, Formal analysis, Validation, Supervision, Writing - review and editing, Project administration. [Confirm this allocation against each author\'s actual contribution before submission; the order shown places Fatimah Azeez Rawdhan as first author and Sarmad K. Ibrahim as corresponding author.]'));
C.push(P('Declaration of competing interest.',{bold:true,after:60}));
C.push(P('The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.'));
C.push(P('Data availability.',{bold:true,after:60}));
C.push(P('This study uses two publicly available measurement corpora, cited in the manuscript, which the authors did not collect. The analysis code, the derived per-replicate records and the scripts that regenerate every table and figure are released at [repository URL]. No new measurement data were collected.'));
C.push(P('Funding.',{bold:true,after:60}));
C.push(P('This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors.'));
C.push(P('Use of generative AI.',{bold:true,after:60}));
C.push(P('[Complete according to the journal policy in force at submission, stating any use of AI tools in preparing the work and confirming that the authors take full responsibility for the content.]'));
C.push(P('Ethics.',{bold:true,after:60}));
C.push(P('The study involves no human participants and no personally identifying data; the corpora contain radio measurements recorded by the original authors from their own devices.'));

C.push(new Paragraph({children:[new PageBreak()]}));
C.push(H1('Pre-submission checklist'));
C.push(P('Items the authors must complete before the manuscript is uploaded. Each is unfinished at the time this package was generated.',{size:19,italics:true}));
C.push(BUL('Verify all 46 references against the publisher record; two are marked [v] as verified, the remainder are not.'));
C.push(BUL('Complete the self-citation with volume, pages and DOI.'));
C.push(BUL('Confirm the corresponding author, the institutional e-mail, and the CRediT allocation drafted above.'));
C.push(BUL('Create the public repository, run the release pipeline once from a clean checkout, and insert its URL in the manuscript, the data-availability statement and this package.'));
C.push(BUL('Confirm the dataset citation that each corpus asks to be used, which may differ from the paper we cite.'));
C.push(BUL('Decide the target journal and reformat to its template; the text is currently in a generic Elsevier style.'));
C.push(BUL('Re-read Section 5.2 and Section 7 for the two concessions a reviewer will press on: the superimposed logging policy and the radio-level reward.'));
C.push(BUL('Regenerate the figure set after the final run so that every number in the text matches the released records.'));

const doc=new Document({
 numbering:{config:[{reference:'b',levels:[{level:0,format:LevelFormat.BULLET,text:'•',
  alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:460,hanging:260}}}}]}]},
 styles:{default:{document:{run:{font:'Times New Roman',size:22}}}},
 sections:[{properties:{page:{margin:{top:1300,bottom:1300,left:1300,right:1300}}},
  footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,
   children:[new TextRun({children:[PageNumber.CURRENT],font:'Times New Roman',size:18,color:'666666'})]})]})},
  children:C}]});
Packer.toBuffer(doc).then(b=>{fs.writeFileSync('/mnt/user-data/outputs/Submission_Package.docx',b);console.log('written');});
