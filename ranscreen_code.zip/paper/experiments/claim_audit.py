"""Recompute the claim audit from saved raw sweeps, with correctly specified predicates.

Two predicates were mis-specified in the first pass and are fixed here:

  * Proposition 1 (zero bias without truncation) must be tested on CELLS where truncation never
    activates, not on the REPLICATES that happened to show no large weight. Conditioning on the
    absence of the tail event is itself a selection and biases the conditional mean - in our data
    by 1.8e-2, two orders of magnitude above the true residual.

  * The charged statistic is pessimistic by construction, so its deviation from the true gain must
    equal minus the charge; that identity, not zero bias, is what should be checked.
"""
from __future__ import annotations
import sys, os
import numpy as np, pandas as pd

M = 20.0


def wilson(k, n, z=1.96):
    p = k/n; d = 1 + z*z/n
    c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return float(c - h), float(c + h)


def audit(raw_path: str, label: str) -> pd.DataFrame:
    R = pd.read_csv(raw_path)
    rows = []
    for keys, g in R.groupby(['temp0', 'n', 'policy', 'charged']):
        t0, n, pol, ch = keys
        k = int((g.lb_t <= g.d_true).sum())
        lo, hi = wilson(k, len(g))
        rows.append(dict(temp0=t0, n=n, policy=pol, charged=ch, reps=len(g),
                         d_true=g.d_true.mean(), d_hat=g.d_hat.mean(),
                         bias=g.d_hat.mean() - g.d_true.mean(), charge=g.charge.mean(),
                         wmax_mean=g.wmax.mean(), wmax_max=g.wmax.max(), ess=g.ess.mean(),
                         coverage=k/len(g), cov_lo=lo, cov_hi=hi, acc=float((g.lb_t > 0).mean()),
                         cov_eb=float((g.lb_eb <= g.d_true).mean()),
                         acc_eb=float((g.lb_eb > 0).mean())))
    A = pd.DataFrame(rows)
    unch, ch = A[~A.charged], A[A.charged]

    never = unch[unch.wmax_max < M]                      # truncation never activates in these cells
    worst_u = unch.nsmallest(1, 'coverage').iloc[0]
    worst_c = ch.nsmallest(1, 'coverage').iloc[0]
    mono = unch[(unch.temp0 == unch.temp0.min()) & (unch.policy == 'aggressive')].sort_values('n')
    gu = unch[(unch.d_true > 0) & (unch.temp0 >= 1.2) & (unch.n == 20_000)].acc.mean()
    gc = ch[(ch.d_true > 0) & (ch.temp0 >= 1.2) & (ch.n == 20_000)].acc.mean()
    pess_err = (ch.bias + ch.charge).abs().max()

    claims = [
        ('standard certificate drops below nominal somewhere',
         f'{worst_u.coverage:.3f} [{worst_u.cov_lo:.3f},{worst_u.cov_hi:.3f}] at '
         f'(T0={worst_u.temp0}, n={worst_u.n:.0f}, {worst_u.policy})', worst_u.cov_hi < 0.90),
        ('charged certificate worst-case coverage',
         f'{worst_c.coverage:.3f} [{worst_c.cov_lo:.3f},{worst_c.cov_hi:.3f}]', worst_c.cov_lo > 0.85),
        ('charged cells whose whole interval is below nominal',
         f'{int((ch.cov_hi < 0.95).sum())} of {len(ch)}', int((ch.cov_hi < 0.95).sum()) <= 3),
        ('power preserved by the charge (T0>=1.2, n=20k)', f'{gu:.3f} -> {gc:.3f}', gc >= gu - 0.02),
        ('coverage degrades as the log grows',
         ' -> '.join(f'{v:.3f}' for v in mono.coverage.values), mono.coverage.values[0] > mono.coverage.values[-1]),
        ('ESS stays high at the worst cell',
         f'{worst_u.ess:.0f} of {worst_u.n:.0f} ({worst_u.ess/worst_u.n:.0%})',
         worst_u.ess/worst_u.n > 0.4),
        ('Prop. 1: zero bias in cells where truncation never activates',
         f'{never.bias.abs().max():.2e} over {len(never)} cells', never.bias.abs().max() < 1e-3),
        ('charged statistic is pessimistic by exactly the charge',
         f'{pess_err:.2e}', pess_err < 5e-3),
        ('maximum weight separates failing from passing cells',
         f'{unch[unch.cov_hi < 0.9].wmax_mean.min():.0f} vs {unch[unch.cov_lo > 0.9].wmax_mean.max():.0f}',
         unch[unch.cov_hi < 0.9].wmax_mean.min() > unch[unch.cov_lo > 0.9].wmax_mean.max()*0.3),
    ]
    C = pd.DataFrame(claims, columns=['claim', 'value', 'passes']).assign(dataset=label)
    A.to_csv(os.path.join(os.path.dirname(raw_path), 'audit_cells.csv'), index=False)
    return C, A


if __name__ == '__main__':
    pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 70)
    out = []
    for label, path in [('4G', '/home/claude/paper/results/4g/audit_sweep_raw.csv'),
                        ('5G', '/home/claude/paper/results/5g/audit_sweep_raw.csv')]:
        if not os.path.exists(path):
            print(f'[{label}] not ready'); continue
        C, A = audit(path, label)
        out.append(C)
        print(f'\n================ {label} ================')
        print(C[['claim', 'value', 'passes']].to_string(index=False))
    if out:
        allc = pd.concat(out)
        allc.to_csv('/home/claude/paper/results/claim_audit.csv', index=False)
        print(f'\n{int(allc.passes.sum())} of {len(allc)} claims pass')
