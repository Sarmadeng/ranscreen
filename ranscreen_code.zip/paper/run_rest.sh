#!/bin/bash
cd /home/claude/paper
export RANSCREEN_NREP=${RANSCREEN_NREP:-250}
for DS in 4g 5g; do
  for E in exp_estimator_family exp_sequential exp_transfer exp_anytime exp_frontier; do
    OUT="results/${DS}/$(echo $E | sed 's/exp_//')_summary.csv"
    if [ -f "$OUT" ]; then echo "SKIP $DS/$E (done)"; continue; fi
    echo "=== START $DS/$E $(date +%H:%M:%S) ==="
    timeout 2400 python3 experiments/$E.py $DS > results/${DS}_${E}.log 2>&1 \
      && echo "=== OK $DS/$E $(date +%H:%M:%S) ===" || echo "=== FAIL/TIMEOUT $DS/$E ==="
  done
done
python3 experiments/make_figures.py 2>&1 | grep -E "wrote|skipped"
echo "ALL DONE $(date +%H:%M:%S)"
